//Abhijeet Sharma
//B15102

Instructions for Our Program

1. Open terminal and move inside the code folder .
2. Type "make" in terminal.
3. Our Output file will be in name as "my_exe"
4. For trying and executing use piping 
	for example 

	{bash} my_exe < input/asc_100.in
